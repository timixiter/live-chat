function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

export default function MessageList({ messages, onMarkAsRead }) {
  if (messages.length === 0) {
    return <p><em>Belum ada permintaan masuk.</em></p>;
  }

  const sorted = [...messages].sort((a, b) => b.id - a.id);

  return (
    <div>
      {sorted.map((msg) => (
        <div key={msg.id} className={`message-item ${msg.sudahDibaca ? 'read' : 'unread'}`}>
          <div className="msg-header">
            <strong>{escapeHtml(msg.nama)}</strong>
            <span style={{ fontSize: '0.9rem', color: '#666' }}>{msg.tanggal}</span>
            <span style={{ marginLeft: '10px', fontSize: '0.8rem' }}>
              {msg.sudahDibaca ? '✅ Sudah dibaca' : '🆕 Belum dibaca'}
            </span>
          </div>
          <div className="msg-email">📧 {escapeHtml(msg.email || '-')}</div>
          <div className="msg-body">{escapeHtml(msg.pesan)}</div>
          {!msg.sudahDibaca && (
            <button className="read-btn" onClick={() => onMarkAsRead(msg.id)}>
              Tandai Dibaca
            </button>
          )}
        </div>
      ))}
    </div>
  );
}